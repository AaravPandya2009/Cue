import test from 'node:test';
import assert from 'node:assert/strict';
import {assess} from './engine.mjs';
import {alignSegments, attachTimes, revealAt, hasFullTimeline} from './timeline.mjs';
import {buildActionPlan} from './action-plan.mjs';

const transcript = 'Hello, I am calling about your account today. Please read me your verification code right now. Buy gift cards.';
const raw = {text:transcript, chunks:[
  {text:'Hello, I am calling about your account today.', timestamp:[0,4]},
  {text:' Please read me your verification code right now.', timestamp:[5,9]},
  {text:' Buy gift cards.', timestamp:[10,null]}
]};
const timing = alignSegments(raw, 12);
test('warning timing maps matching text to estimated segment start', () => {
  const result = attachTimes(assess(transcript,12),timing.segments);
  assert.equal(result.evidence.find(e=>e.id==='secret').timestamp,5);
  assert.equal(result.evidence.find(e=>e.id==='payment').timestamp,10);
  assert.equal(result.evidence.find(e=>e.id==='payment').timestampPrecision,'approximate segment start');
});
test('simulation withholds future transcript and warnings and rewinds correctly', () => {
  assert.equal(revealAt(transcript,timing.segments,0),'');
  const first = revealAt(transcript,timing.segments,4);
  assert.ok(!assess(first).evidence.some(e=>e.id==='secret'));
  const second = revealAt(transcript,timing.segments,9);
  assert.ok(assess(second).evidence.some(e=>e.id==='secret'));
  assert.ok(!assess(second).evidence.some(e=>e.id==='payment'));
  assert.equal(revealAt(transcript,timing.segments,12),transcript);
  assert.equal(revealAt(transcript,timing.segments,4),first);
});
test('missing, misaligned, and invalid timing is not invented', () => {
  assert.ok(hasFullTimeline(transcript,timing.segments));
  assert.equal(hasFullTimeline(transcript,[]),false);
  assert.equal(hasFullTimeline(transcript,timing.segments.slice(1)),false);
  assert.deepEqual(alignSegments({text:'Hello',chunks:[{text:'Hello',timestamp:[null,null]}]},5).segments,[]);
  assert.deepEqual(alignSegments({text:'Hello',chunks:[{text:'Different words',timestamp:[0,2]}]},5).segments,[]);
  const bad = alignSegments({text:'Hello there',chunks:[{text:'Hello',timestamp:[0,3]},{text:'there',timestamp:[2,4]}]},5);
  assert.equal(hasFullTimeline(bad.text,bad.segments),false);
});
test('action plans match explicit answers and deduplicate shared steps', () => {
  assert.deepEqual(buildActionPlan(),[]);
  assert.deepEqual(buildActionPlan(['unknown']),[]);
  assert.equal(buildActionPlan(['money']).length,2);
  assert.ok(!buildActionPlan(['money']).some(s=>s.id==='password-change'));
  const all = buildActionPlan(['code','password','money','access']);
  assert.equal(all.length,7);
  assert.equal(new Set(all.map(s=>s.id)).size,all.length);
  assert.equal(buildActionPlan(['code','code']).length,2);
});
