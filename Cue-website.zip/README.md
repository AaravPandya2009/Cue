# Cue

A local website prototype for explaining recorded-call screening. No publication, account, API key, or paid service required.

The footer links to `privacy.html` and `terms.html` in separate tabs, preserving the active call analysis. These pages describe the local prototype's actual data flow, external downloads, session storage, saved reports, permitted use, and analysis limits. They are prototype documents, not a statement of legal compliance for a future public service; revisit them if hosting, data handling, ownership, or contact arrangements change.

## Open

Double-click `Start Cue.cmd` with Node.js installed, or run `node server.cjs` in this folder and open http://127.0.0.1:4173. Keep the server window open while using it.

Choose an English recording, then select **Analyze recording**. Audio is decoded locally, resampled to 16 kHz mono, and transcribed using Whisper tiny.en in a web worker. First use downloads model files from Hugging Face and the Transformers.js runtime from jsDelivr. Fonts load from Google Fonts. Audio and transcripts are not sent to these services. The downloaded model may be cached by the browser. Files and transcripts stay in memory unless you explicitly save a report.

Paste a transcript and select **Analyze text** for a model-free fallback. Three labeled sample transcripts support presentations without model downloads. Audio is limited to 25 MB and five minutes to keep this prototype manageable. Recognition speed depends on the device. Use a recent desktop browser.

## What the prototype actually measures

- Tone: transcript pressure/threat phrases, not voice emotion or accent.
- Pace: transcript words divided by full audio duration; includes pauses and both speakers; does not affect the score.
- Processes: explicit language patterns involving secrets, payments, remote access, or prizes.
- Reliability: unverified authority claims and attempts to discourage independent verification. No phone reputation or identity database is connected.

`engine.mjs` contains transparent weighted rules capped at 100. This is an unvalidated heuristic index, not a fraud probability. Under 12 words returns insufficient context. Rules can miss paraphrases, fail to attribute speakers, and misread negation or quoted warnings. Whisper can mishear or invent text. Review transcripts and evidence. A low score does not establish safety.

## Presentation wording

“This prototype analyzes an uploaded recording. Uploading stands in for the live audio stream in the future app. It shows a risk assessment and its reasons. The current version uses local transcription and simple, explainable rules; it does not yet monitor live calls or verify caller identity.”

## Implementation references

- https://huggingface.co/docs/transformers.js/v2.17.2/en/api/pipelines
- https://huggingface.co/Xenova/whisper-tiny.en

No live call interception, phone permissions, or public deployment is included.

## Verified demo
Included example-suspicious-call.wav is a synthetic speech recording for demonstrations. The full browser upload, local transcription, pace calculation, and risk report were tested with it. Both sample-transcript buttons and five scoring checks also passed.

## Action guidance and theme
The interface uses black surfaces and red accents. Reports now include next steps selected from the matched call cues, with expandable recovery guidance for sensitive information, payments, or remote access. Tips and their FTC source links are included in saved reports. An always-visible Action tips section offers general guidance before analysis. Guidance selection was checked for ordinary calls, code/payment requests, remote access, and insufficient context.

## Timestamps, live simulation, and personal checklists

1. Choose a recording and analyze it, or click **Load audio demo** to load and transcribe the included synthetic recording.
2. In **What stood out**, each timed warning has a play button. It seeks to the estimated start of the matching Whisper speech segment, not an exact word boundary. Unaligned warnings are left untimed.
3. Select **Live demo**, then **Play demo**. This replays already-transcribed audio. Completed transcript segments and their warnings are revealed against the audio player's actual clock. Pause, restart, seek, and playback speed use that same clock. Rewinding removes future warnings; **Full assessment** restores the complete result. This is not streaming recognition or live call access. If complete segment alignment is unavailable, live mode is disabled.
4. Under **Your action checklist**, select whether you shared a code/password, sent money, or installed software/allowed access. Mark individual steps as completed. Shared steps are deduplicated. These answers never change the risk score. They remain in memory across playback changes and clear when loading another call or resetting. Completion is self-reported.
5. **Save report** includes estimated evidence timestamps, the selected situations, completed steps, and whether the report is a partial simulation assessment. A partial report contains only the revealed transcript. Editing the transcript invalidates audio timing to avoid stale timestamp links.

Validation: `node --test features.test.mjs` covers evidence-to-segment alignment, progressive reveal and rewind, invalid/incomplete timing, and personalized/deduplicated plans. Browser verification includes actual demo transcription, timestamp seeking, live replay and restart, and checklist persistence.

## Highlights, speakers, schemes, and presenting

- **Explore the transcript** highlights the exact phrases behind warnings. Click a highlight for its explanation and an estimated audio timestamp when available. Overlapping warnings preserve the original text.
- Each excerpt has a manual **Caller / Recipient / Unknown** label. Explicit `Caller:` and `Recipient:` text prefixes populate these labels. Recipient speech is excluded from scoring and scheme matching; unknown speech is included. This is not automatic voice identification. Editing transcript text resets labels and feedback.
- Reports identify a call type and possible scheme patterns, including pyramid, Ponzi, investment-return, advance-fee, bank-impersonation, tech-support, and prize patterns. Combinations of cues trigger a label; mentioning a scheme name alone does not. Quotes explain the match, with FTC or Investor.gov links. These English-language rules are not a complete or validated fraud detector and can misunderstand quotations, negation, or context.
- **Try a pyramid scheme △** loads a fictional, labeled transcript and immediately analyzes it. It demonstrates a joining fee, recruitment, recruitment-based commissions, and no products being sold. It is a text example, with no audio recording.
- Uploaded recordings receive basic checks for silence, quiet volume, short duration, possible clipping, and a possible steady noise floor. These signal checks cannot establish intelligibility or reliably distinguish noise from speech. They never increase the risk score; near-silent recordings cannot be transcribed.
- **Present ↗** opens a simplified presentation view with a large result, highlighted conversation, scheme labels, and key warnings. Timed audio supports full assessment or simulated live playback, shared play/pause and restart controls, and the same recording clock. Browser fullscreen is optional and depends on browser support.
- Each warning accepts **Helpful** or **Seems incorrect**, plus optional notes. Feedback stays in this tab, does not train a model, and is included in **Save report**, together with speaker labels and audio-quality checks. Loading a new call or resetting clears it.

Validation: `node --test features.test.mjs insights.test.mjs` passes 10 tests covering timing, action plans, combined scheme cues, benign/negated examples, speaker exclusion, highlight offsets, audio signal checks, and live-prefix scheme detection. Browser checks cover the pyramid example, highlight explanations, role changes that remove and restore a scheme flag, feedback, actual demo transcription, and presentation controls.
