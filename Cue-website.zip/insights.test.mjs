import test from 'node:test';
import assert from 'node:assert/strict';
import {analyzeCall,pyramidExample,splitTurns,highlightRanges} from './insights.mjs';
import {checkAudioQuality} from './audio-quality.mjs';

test('pyramid example requires several quoted cues, not the scheme name',()=>{
 const result=analyzeCall(pyramidExample);
 assert.ok(result.classification.schemes.some(s=>s.id==='pyramid'));
 assert.ok(result.score>=60);
 const pattern=result.classification.schemes.find(s=>s.id==='pyramid');
 assert.ok(pattern.cues.length>=3);
 for(const cue of pattern.cues)assert.equal(pyramidExample.slice(cue.start,cue.end),cue.text);
 const educational=analyzeCall('We discussed a pyramid scheme in class today. Please read the textbook chapter for tomorrow.');
 assert.equal(educational.classification.schemes.length,0);
});
test('specific schemes and call types need the relevant combination of cues',()=>{
 const cases=[
  ['ponzi','We use money from new investors to pay existing investors. This is how our investment fund keeps paying.'],
  ['investment','Invest in this trading fund for guaranteed returns. Deposit money into the account to get started today.'],
  ['advance-fee','Your loan is ready. Send an upfront fee first and then we will release the promised money.'],
  ['bank','I am calling from your bank. Please read me your verification code right now to unlock the account.'],
  ['tech','This is Microsoft technical support. Install this app so I can get remote access to your computer.'],
  ['prize','You have won a lottery prize. Buy gift cards to claim your prize from our office today.']
 ];
 for(const [id,text]of cases)assert.ok(analyzeCall(text).classification.schemes.some(s=>s.id===id),id);
 assert.equal(analyzeCall('Our business sells products to customers. You do not earn money by recruiting new members.').classification.schemes.length,0);
 assert.equal(analyzeCall('This investment offers no guaranteed returns. You can lose the money you put into it.').classification.schemes.length,0);
});
test('recipient speech does not incriminate the caller or complete a scheme',()=>{
 const text='Caller: Hello, I am calling about the community meeting on Saturday morning at the town hall.\nRecipient: Read me your verification code right now.';
 const turns=splitTurns(text),clean=analyzeCall(text,null,turns);
 assert.equal(clean.score,0);
 assert.ok(!clean.evidence.some(e=>e.id==='secret'));
 const changed=turns.map(t=>({...t,speaker:'unknown'}));
 assert.ok(analyzeCall(text,null,changed).evidence.some(e=>e.id==='secret'));
 const split='Caller: Pay $500 to join our membership program. Please read the handbook for the rest of the details.\nRecipient: You earn commissions by recruiting new members. Recruit three friends.';
 assert.ok(!analyzeCall(split).classification.schemes.some(s=>s.id==='pyramid'));
 assert.equal(analyzeCall(text,null,turns.map(t=>({...t,speaker:'recipient'}))).score,null);
});
test('speaker offsets preserve Unicode and highlights include repeated evidence without overlap',()=>{
 const text='Caller: 🙂 Act immediately. Read me your verification code. Please read me your verification code again.';
 const turns=splitTurns(text),result=analyzeCall(text,null,turns);
 assert.ok(turns.every(t=>text.slice(t.start,t.end).trim()));
 assert.equal(result.evidence.find(e=>e.id==='secret').occurrences.length,2);
 const ranges=highlightRanges(result.evidence,text.length);
 for(let i=0;i<ranges.length;i++){assert.ok(text.slice(ranges[i].start,ranges[i].end));if(i)assert.ok(ranges[i].start>=ranges[i-1].end);}
 assert.ok(!analyzeCall('Never share your password. Never buy gift cards to pay an unknown caller who contacts you.').evidence.some(e=>e.id==='secret'||e.id==='payment'));
});
test('quality checks distinguish silence, quiet, short, clipped, and steady audio',()=>{
 const rate=16000;
 const make=(seconds,amp)=>Float32Array.from({length:seconds*rate},(_,i)=>amp*Math.sin(i*.1)*(i%16000<10000?1:0));
 assert.ok(checkAudioQuality(new Float32Array(rate*10)).blocked);
 assert.ok(checkAudioQuality(make(10,.001)).issues.some(i=>i.id==='quiet'));
 assert.ok(checkAudioQuality(make(3,.2)).issues.some(i=>i.id==='short'));
 assert.ok(checkAudioQuality(Float32Array.from({length:rate*10},(_,i)=>i%2?1:-1)).issues.some(i=>i.id==='clipping'));
 assert.ok(checkAudioQuality(Float32Array.from({length:rate*10},(_,i)=>.1*Math.sin(i*.1))).issues.some(i=>i.id==='steady'));
 assert.equal(checkAudioQuality(make(12,.2)).issues.length,0);
});
test('unrevealed future scheme cues do not appear in live assessment',()=>{
 const cut=pyramidExample.indexOf('Caller: There are');
 const partial=pyramidExample.slice(0,cut),turns=splitTurns(pyramidExample);
 assert.ok(!analyzeCall(partial,null,turns).classification.schemes.some(s=>s.id==='pyramid'));
});
